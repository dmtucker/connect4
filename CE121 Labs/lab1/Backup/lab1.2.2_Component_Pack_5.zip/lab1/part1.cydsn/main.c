#include <device.h>


void main () {
    ADC_Start();
    LCD_Start();
    //PWM_Init();
    while (1) {
        ADC_GetResult16();
        /* Place your application code here. */
    }
}
