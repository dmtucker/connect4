#include <device.h>

void main () {
    LCD_Start();
    LCD_Position(0,0);
    LCD_PrintString("initializing...");
    ADC_Start();
    ADC_StartConvert();
    PWM_Start();
    LCD_ClearDisplay();
    
    LCD_Position(0,0);
    LCD_PrintString("running...");
    LCD_Position(1,0);
    LCD_PrintString("brightness: ");
    while (ADC_IsEndConversion(ADC_WAIT_FOR_RESULT)) {
        unsigned int brightness = ADC_GetResult16();
        LCD_Position(1,12);
        LCD_PrintInt16(brightness);
        PWM_Enable();
        PWM_WriteCounter(brightness/65u);
        PWM_WriteControlRegister(PWM_ReadControlRegister() & 0x7FFF);
    }
}
