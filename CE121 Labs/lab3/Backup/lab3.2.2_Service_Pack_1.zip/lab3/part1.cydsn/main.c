#include <device.h>


static const uint16 PACKET_LENGTH = 4096;
static const uint16 POST_TIME     = 2000;


void LCD_Spin (int row, int col, int speed, int count) {
    for (; count > 0 ;--count) {
        LCD_Position(row,col);
        LCD_PutChar('|');
        CyDelay(speed*3/8);
        LCD_Position(row,col);
        LCD_PutChar('/');
        CyDelay(speed/4);
        LCD_Position(row,col);
        LCD_PutChar('-');
        CyDelay(speed*3/8);
        //LCD_Position(row,col);
        //LCD_PutChar('\\');
        //CyDelay(speed/4);
    }
}


void LCD_ClearLine (int line) {
    LCD_Position(line,0);
    LCD_PrintString("                ");
}


void LCD_UpdateStatus (const char string[]) {
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString(string);
}


void LCD_UpdateMessage (const char string[]) {
    LCD_ClearLine(1);
    LCD_Position(1,0);
    LCD_PrintString(string);
}


void main () {
    LCD_Start();
    
    LCD_UpdateStatus("initializing...");
    UART_Start();
    UART_ClearTxBuffer();
    UART_ClearRxBuffer();
    uint8 outgoing[PACKET_LENGTH];
    uint8 incoming[PACKET_LENGTH];
    uint16 i;
    for (i=0; i < PACKET_LENGTH ;++i) {
        outgoing[i] = (uint8) i; // [0,255]*16
        incoming[i] = 0;
    }
    
    LCD_UpdateStatus("running...");
    while (1) {
        uint16 errors = 0;
        for (i=0; i < PACKET_LENGTH ;++i) {
            UART_WriteTxData(outgoing[i]);
            CyDelay(1); //propagation
            incoming[i] = UART_ReadRxData();
            if (i == 0) LCD_UpdateMessage("transferred");
            LCD_Position(1,12);
            LCD_PrintInt16(i);
            if (incoming[i] != outgoing[i]) {
                LCD_UpdateMessage("error");
                ++errors;
                CyDelay(POST_TIME);
                LCD_UpdateMessage("transferred");
            }
        }
        LCD_UpdateMessage("transfer done");
        CyDelay(POST_TIME);
        LCD_ClearLine(1);
        LCD_Position(1,0);
        if (errors == 0) {
            LCD_PrintString("no");
            LCD_Position(1,3);
        }
        else {
            LCD_PrintInt16(errors);
            LCD_Position(1,5);
        }
        LCD_PrintString("errors");
        CyDelay(POST_TIME);
    }
    
    LCD_UpdateStatus("cleaning...");
    UART_Stop();
    LCD_Stop();
}
