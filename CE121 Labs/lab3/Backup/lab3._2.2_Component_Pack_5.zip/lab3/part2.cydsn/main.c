#include <device.h>
#include <stdbool.h>




static const uint16 PACKET_LENGTH = 4096;
static const uint16 POST_TIME     = 2000;

uint8 outgoing[4096]; //uint8 outgoing[PACKET_LENGTH];
uint8 incoming[4096]; //uint8 incoming[PACKET_LENGTH];
uint16 tx_cursor = 4096; //PACKET_LENGTH
uint16 rx_cursor = 4096; //PACKET_LENGTH
bool packet = false;



void LCD_Spin (int row, int col, int speed, int count) {
    for (; count > 0 ;--count) {
        LCD_Position(row,col);
        LCD_PutChar('|');
        CyDelay(speed*3/8);
        LCD_Position(row,col);
        LCD_PutChar('/');
        CyDelay(speed/4);
        LCD_Position(row,col);
        LCD_PutChar('-');
        CyDelay(speed*3/8);
        //LCD_Position(row,col);
        //LCD_PutChar('\\');
        //CyDelay(speed/4);
    }
}




void LCD_ClearLine (int line) {
    LCD_Position(line,0);
    LCD_PrintString("                ");
}




void LCD_UpdateStatus (const char string[]) {
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString(string);
}




void LCD_UpdateMessage (const char string[]) {
    LCD_ClearLine(1);
    LCD_Position(1,0);
    LCD_PrintString(string);
}




CY_ISR (ISR_tx) {
    LCD_UpdateMessage("sending");
    LCD_Position(0,14);
    LCD_PrintString("tx");
    int i;
    for (i = 0; i < 4 && tx_cursor < PACKET_LENGTH ;++i) {
        UART_WriteTxData(outgoing[tx_cursor++]);
        LCD_Position(1,8);
        LCD_PrintInt8(outgoing[tx_cursor-1]);
        LCD_Position(1,12);
        LCD_PrintInt16(tx_cursor);
        CyDelay(500);
    }
}




CY_ISR (ISR_rx) {
    if (rx_cursor) {
        LCD_UpdateMessage("received");
        LCD_Position(0,14);
        LCD_PrintString("rx");
        incoming[rx_cursor++] = UART_ReadRxData();
        LCD_Position(1,9);
        LCD_PrintInt8(incoming[rx_cursor-1]);
        LCD_Position(1,12);
        LCD_PrintInt16(rx_cursor);
        CyDelay(500);
        if (rx_cursor == 4096) packet = true;
        /*
        if (incoming[rx_cursor-1] != outgoing[rx_cursor-1]) {
            LCD_UpdateMessage("error");
            LCD_Position(1,6);
            LCD_PrintInt8(incoming[rx_cursor-1]);
            LCD_Position(1,9);
            LCD_PrintString("!=");
            LCD_Position(1,12);
            LCD_PrintInt8(outgoing[rx_cursor-1]);
            ++errors;
            CyDelay(POST_TIME);
            LCD_ClearLine(1);
        }
        */
    }
}




void main () {
    LCD_Start();
    
    
    LCD_UpdateStatus("initializing...");
    UART_Start();
    UART_ClearTxBuffer();
    UART_ClearRxBuffer();
    uint16 i;
    for (i=0; i < PACKET_LENGTH ;++i) {
        outgoing[i] = (uint8) i; // [0,255]*16 = [0x00,0xFF]*16
        incoming[i] = 0;
    }
    CyGlobalIntEnable;
    txISR_StartEx(ISR_tx);
    rxISR_StartEx(ISR_rx);
    
    
    LCD_UpdateStatus("running...");
    while (true) {
        tx_cursor = 0;
        rx_cursor = 0;
        packet = false;
        ISR_tx();
        /*
        for (i = 0; i < 4 && tx_cursor < PACKET_LENGTH ;++i) {
            UART_WriteTxData(outgoing[tx_cursor++]);
            LCD_Position(1,8);
            LCD_PrintInt8(outgoing[tx_cursor-1]);
            LCD_Position(1,12);
            LCD_PrintInt16(tx_cursor);
            CyDelay(500);
        }
        */
        while (!packet);
        LCD_UpdateMessage("transfer done");
        CyDelay(POST_TIME);
        uint16 errors = 0;
        for (i=0; i < PACKET_LENGTH ;++i) if (incoming[i] != outgoing[i]) ++errors;
        LCD_ClearLine(1);
        LCD_Position(1,0);
        if (errors == 0) {
            LCD_PrintString("no");
            LCD_Position(1,3);
        }
        else {
            LCD_PrintInt16(errors);
            LCD_Position(1,5);
        }
        LCD_PrintString("errors");
        CyDelay(POST_TIME);
    }
    
    
    LCD_UpdateStatus("cleaning...");
    UART_Stop();
    LCD_Stop();
}
