#include <device.h>
#include <stdbool.h>
#include <PID.h>




double Input, Output, Setpoint;
double ITerm, lastInput;
double kp, ki, kd;
int SampleTime = 1000; //ms
double outMin, outMax;
bool mode = MANUAL;
int direction = DIRECT;




void set_direction (int newDirection) {
    direction = newDirection;
}




void set_input (double newInput) {
    Input = newInput;
}




void set_output_limits (double min, double max) {
   if (min > max) return;
   outMin = min;
   outMax = max;
 
   if      (Output > outMax) Output = outMax;
   else if (Output < outMin) Output = outMin;
 
   if      (ITerm > outMax) ITerm = outMax;
   else if (ITerm < outMin) ITerm = outMin;
}




void set_sample_time (int newSampleTime) {
   if (newSampleTime > 0) {
      double ratio = (double) newSampleTime/(double) SampleTime;
      ki *= ratio;
      kd /= ratio;
      SampleTime = (unsigned long) newSampleTime;
   }
}




void set_tunings (double Kp, double Ki, double Kd) {
    if (Kp < 0 || Ki < 0 || Kd < 0) return;

    double SampleTimeInSec = ((double) SampleTime)/1000;
    kp = Kp;
    ki = Ki * SampleTimeInSec;
    kd = Kd / SampleTimeInSec;

    if (direction == REVERSE) {
        kp = 0-kp;
        ki = 0-ki;
        kd = 0-kd;
    }
}



double PID_compute () {
    if (mode != AUTOMATIC) return -1;
    
    /*Compute all the working error variables*/
    double error = Setpoint - Input;
    ITerm += ki*error;
    if      (ITerm > outMax) ITerm = outMax;
    else if (ITerm < outMin) ITerm = outMin;
    double dInput = Input-lastInput;

    /*Compute PID Output*/
    Output = kp*error + ITerm - kd*dInput;
    if      (Output > outMax) Output = outMax;
    else if (Output < outMin) Output = outMin;

    /*Remember some variables for next time*/
    lastInput = Input;
    
    return Output;
}




bool get_mode () {
    return mode;
}




void set_mode (int newMode) {
    bool newAuto = (newMode == AUTOMATIC);
    if (newAuto != mode) {
        lastInput = Input;
        ITerm     = Output;
        if      (ITerm > outMax) ITerm = outMax;
        else if (ITerm < outMin) ITerm = outMin;
    }
    mode = newAuto;
}




int toggle_mode () {
    set_mode((mode == MANUAL) ? AUTOMATIC : MANUAL);
    return mode;
}




double get_setpoint () {
    return Setpoint;
}




void set_setpoint (double newSetpoint) {
    Setpoint = newSetpoint;
    if      (Setpoint > outMax) Setpoint = outMax;
    else if (Setpoint < outMin) Setpoint = outMin;
}
