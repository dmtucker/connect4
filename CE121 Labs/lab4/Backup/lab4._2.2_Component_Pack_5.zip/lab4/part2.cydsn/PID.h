#include <stdbool.h>

#define MANUAL false
#define AUTOMATIC true
#define DIRECT false
#define REVERSE true

#ifndef PID_H
#define PID_H
void set_direction (int newDirection);
void set_input (double newInput);
void set_output_limits (double Min, double Max);
void set_sample_time (int newSampleTime);
void set_tunings (double Kp, double Ki, double Kd);
double PID_compute ();
bool get_mode ();
void set_mode (int mode);
int toggle_mode ();
double get_setpoint ();
void set_setpoint (double newSetpoint);
#endif