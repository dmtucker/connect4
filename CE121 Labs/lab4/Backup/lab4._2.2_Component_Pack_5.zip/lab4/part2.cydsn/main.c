#include <device.h>
#include <stdbool.h>
#include <display.h>
#include <PID.h>

#define SLOWEST 5000
#define FASTEST 22000




CY_ISR (toggle) {
    Indicator_Write((toggle_mode() == AUTOMATIC) ? 0x01 : 0x00);
}

CY_ISR (sample) {
    if (get_mode() == AUTOMATIC) PWM_WriteCompare((uint16) (PID_compute()*PWM_ReadPeriod()/FASTEST));
}




void main () {
    LCD_Start();
    LCD_UpdateStatus("initializing...");
    LCD_UpdateMessage("Clock");
    Clock_Start();
    LCD_UpdateMessage("ADC");
    ADC_Start();
    ADC_StartConvert();
    LCD_UpdateMessage("PWM");
    PWM_Start();
    LCD_UpdateMessage("Counter");
    Counter_Start();
    LCD_UpdateMessage("Timer");
    Timer_Start();
    LCD_UpdateMessage("PID");
    set_output_limits(SLOWEST,FASTEST);
    //set_tunings(0.16,0.8,0.005); //thanks Jeff
    //set_tunings(0.5,0.005,0); //DEBUG - lower limits
    //set_tunings(5,0.05,20); //DEBUG - upper limits
    //set_tunings(2.75,0.0275,10); //DEBUG - averages
    set_tunings(1.887,0.285,6.6683); //Jeff averages
    LCD_UpdateMessage("Interrupts");
    CyGlobalIntEnable;
    Sample_StartEx(sample);
    Mode_StartEx(toggle);
    
    
    LCD_UpdateStatus("  RPM:");
    LCD_UpdateMessage("speed:");
    LCD_Position(1,14);
    LCD_PrintInt8(PWM_ReadPeriod());
    while (ADC_IsEndConversion(ADC_WAIT_FOR_RESULT)) {
        uint16 speed = ADC_GetResult16();
        uint16 rpm = Counter_ReadCapture()*60/2;
        if (get_mode() == MANUAL) {
            LCD_Position(1,0);
            LCD_PrintString("speed:   %  ");
            LCD_Position(1,7);
            LCD_PrintNumber(speed*100/65535);
            PWM_WriteCompare(speed*PWM_ReadPeriod()/65535);
        }
        else {
            LCD_Position(1,0);
            LCD_PrintString("setPt:      ");
            LCD_Position(1,7);
            LCD_PrintNumber(speed*FASTEST/65535);
            set_setpoint((double) speed*FASTEST/65535);
            set_input((double) rpm);
        }
        LCD_Position(0,7);
        LCD_PrintString("     ");
        LCD_Position(0,7);
        LCD_PrintNumber(rpm);
        LCD_Position(0,14);
        LCD_PrintInt8(PWM_ReadCounter());
    }
    
    
    LCD_UpdateStatus("cleaning...");
    LCD_UpdateMessage("Interrupts");
    Mode_Stop();
    Sample_Stop();
    LCD_UpdateMessage("Timer");
    Timer_Stop();
    LCD_UpdateMessage("Counter");
    Counter_Stop();
    LCD_UpdateMessage("PWM");
    PWM_Stop();
    LCD_UpdateMessage("ADC");
    ADC_Stop();
    LCD_UpdateMessage("Clock");
    Clock_Stop();
}
